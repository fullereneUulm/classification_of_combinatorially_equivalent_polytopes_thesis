#ifndef Y3TABLE_HH
# define Y3TABLE_HH

#include <inttypes.h>
namespace Y3Table {
const uint16_t Nvalues = 1089, Nindices = 169;
extern const uint16_t indices[169], keys[1089];
extern const double values[1089];
}
#endif
